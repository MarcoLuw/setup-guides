from collections import defaultdict

import boto3
import json
import os
import uuid

from datetime import datetime

s3 = boto3.resource('s3')

ssm_client = boto3.client('ssm')

team_id = None
event_id = None
central_bucket_name = None


failed_requests = defaultdict(list)
successful_requests = defaultdict(list)


def log_failed_request(request_id, request):
	failed_requests[request_id].append(request)


def log_successful_request(request_id, request):
	successful_requests[request_id].append(request)


# consider a class to hold this detail
def flush_logs(step_name, step_number, policy_json, is_advanced):
	if not should_log():
		return

	if len(failed_requests) > 0:
		log_entry = _build_log_entry('FAIL', step_name, step_number, policy_json, is_advanced)
	else:
		log_entry = _build_log_entry('PASS', step_name, step_number, policy_json, is_advanced)

	_try_send_log_entry(log_entry)


def _build_log_entry(evaluation_result, step_name, step_number, policy_json, is_advanced):
	return {
		'entryId': str(uuid.uuid4()),
		'eventId': event_id,
		'teamId': os.environ.get('TEAM_ID'),
		'accountNumber': os.environ.get('AWS_ACCOUNT_ID'),
		'evaluationDateTimeUtc': datetime.utcnow().isoformat(),
		'evaluationResult': evaluation_result,
		'stepDescription': step_name,
		'stepNumber': step_number,
		'isAdvanced': is_advanced,
		'policy': policy_json,
		'failedRequests': failed_requests,
		'successfulRequests': successful_requests
	}


def _try_send_log_entry(log_entry):
	try:
		filename = f'eval_results/{log_entry["teamId"]}/{log_entry["evaluationDateTimeUtc"]}.json'
		s3_object = s3.Object(central_bucket_name, filename)
		s3_object.put(
			Body=bytes(json.dumps(log_entry).encode('UTF-8'))
		)
	except Exception as e:
		# ignore and continue, logging is best effort
		pass


def should_log():
	return os.environ.get('IS_AWS_EVENT', 'False') == 'True'


try:
	if should_log():
		# don't attempt to make the request unless we know we're at an event
		response = ssm_client.get_parameters(
			Names=[
				'workshop_studio_central_s3_bucket_name',
				'workshop_studio_central_account_id'
			]
		)
		parameters = response.get('Parameters', [])
		central_bucket_name = next(iter([param['Value'] for param in parameters if param['Name'] == 'workshop_studio_central_s3_bucket_name']), None)
		event_id = next(iter([param['Value'] for param in parameters if param['Name'] == 'workshop_studio_central_account_id']), None)
except Exception as e:
	# it's possible that these parameters don't exist yet, so do nothing if they do not
	pass
