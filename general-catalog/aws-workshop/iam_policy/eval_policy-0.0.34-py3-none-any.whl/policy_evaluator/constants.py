my_account_number = '111111111111'


class bcolors:
	OKGREEN = '\033[92m'
	BLUE = '\033[94m'
	WARNING = '\033[93m'
	FAIL = '\033[91m'
	END = '\033[0m'
	BOLD = '\033[1m'


perimeter_on_network = 'network'
perimeter_on_resource = 'resource'
perimeter_on_identity = 'identity'

my_resource_name = 'my-bucket'

my_account_root = f'arn:aws:iam::{my_account_number}:root'
my_default_role_name = 'MyRole'
my_role_arn = f'arn:aws:iam::{my_account_number}:role/{my_default_role_name}'

# another account that's in the same org as this account
my_other_account_number = '999999999999'
my_role_in_other_account_arn = f'arn:aws:iam::{my_other_account_number}:role/MyRole'
my_organization_id = 'o-123456'

service_linked_role_arn = f'arn:aws:iam::{my_account_number}:role/aws-service-role/AWSServiceRoleForTesting'

not_my_role_name = 'NotMyRole'
not_my_account_number = '222222222222'
not_my_account_root = f'arn:aws:iam::{not_my_account_number}:root'
not_my_role_arn = f'arn:aws:iam::{not_my_account_number}:role/{not_my_role_name}'
not_my_organization_id = 'o-999999'

service_principal_account_number = '444444444444'
service_principal_role_arn = f'arn:aws:iam::{service_principal_account_number}:role/ServicePrincipalRole'
service_principal_organization_id = 'o-444444'

not_my_service_linked_role_arn = f'arn:aws:iam::{not_my_account_number}:role/aws-service-role/AWSServiceRoleForTesting'


my_on_premises_ips = ['192.0.2.1', '198.51.100.1']
my_vpc_ids = ['vpc-12345678', 'vpc-99999999']
my_vpce_id = 'vpce-123456'

not_my_on_premises_ip = '203.0.113.0'
not_my_vpc_id = 'vpc-22222222'
not_my_vpce_id = 'vpce-22222222'


class ValidationException(Exception):
	def __init__(self, message):
		message = f'{bcolors.FAIL}ERROR: {message}{bcolors.END}'
		super().__init__(message)
