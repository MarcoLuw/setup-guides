from policy_evaluator.constants import bcolors

default_col1_size = 10
default_col2_size = 15
default_col3_size = 15
default_col4_size = 80


def __calculate_column_size(column_text, default_size):
	if bcolors.BOLD in column_text:
		return default_size + 4

	if bcolors.FAIL in column_text:
		return default_size + 9

	if bcolors.OKGREEN in column_text:
		return default_size + 9

	return default_size


def build_string(col1, col2, col3, col4):
	col1_size = __calculate_column_size(col1, default_col1_size)
	col2_size = __calculate_column_size(col2, default_col2_size)
	col3_size = __calculate_column_size(col3, default_col3_size)
	col4_size = __calculate_column_size(col4, default_col4_size)

	my_string = f'{col1:{col1_size}}{col2:{col2_size}}{col3:{col3_size}}{col4:{col4_size}}'
	return my_string


def build_request_error(error):
	return build_string(' ', ' ', ' ', error) + '\n'
