import json
import sys
import argparse
import traceback

#import os
#os.environ['IS_AWS_EVENT'] = 'True'

from policy_evaluator import policy_validator
from policy_evaluator.version import __version__
from policy_evaluator.constants import ValidationException, bcolors
from policy_evaluator.steps.map import step_evaluator


def main(args=None):
    if args is None:
        args = sys.argv[1:]

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--version', action='version', version='%(prog)s ' + __version__)
    parser.add_argument('--policy', metavar="POLICY", dest="policy", required=True, help='The path to the IAM policy to evaluate.')
    parser.add_argument('--step', metavar="STEP", dest="step", required=True, help='The step of the workshop you are working on.')
    parser.add_argument('--advanced', default=False, action='store_true')

    args = parser.parse_args(args)
    _run(args.step, args.policy, args.advanced)


def _run(step_number, policy, include_advanced):
    try:
        with open(policy) as f:
            try:
                policy = json.load(f)
            except ValueError as e:
                raise ValidationException(f'The policy you submitted is not valid JSON. Trailing commas, missing quotes, '
                                          f'and missing/extra brackets are common mistakes.\nDetailed error message:  {str(e)}')

        print(f'{bcolors.BLUE}Running checks for step: {step_number}\nPolicy being evaluated: {json.dumps(policy, indent=4)}{bcolors.END}\n')

        step_class = step_evaluator.get(step_number)
        if step_class is None:
            raise ValidationException(
                f'Invalid step number {step_number}.  Valid step numbers are {", ".join(step_evaluator.keys())}.')

        step_policy_checks = step_class(step_number)
        policy_validator.validate(step_number, step_policy_checks, policy)
        step_policy_checks.evaluate(policy, include_advanced)
    except ValidationException as e:
        print(str(e))
        exit(1)
    except Exception as e:
        traceback.print_exc()
        print(f'ERROR: Unexpected error occurred. {str(e)}', file=sys.stderr)
        exit(1)


if __name__ == "__main__":
    import os
    this_files_directory = os.path.dirname(os.path.realpath(__file__))

    test_run = '3'
    include_advanced = False
    test_files = {
        '1': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_1.json'),
        '2': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_2.json'),
        '3': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_3.json'),
        '4': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_4.json'),
        '5': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_5.json'),
        '6': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_6.json'),
        '7': os.path.join(this_files_directory, '..', 'tests', 'policies', 'test_step_7.json')
    }

    test_file_path = test_files[test_run]

    if include_advanced:
        test_file_path = test_file_path.replace('.json', '_advanced.json')

    os.environ['TEAM_ID'] = 'teamabc-123'
    os.environ['AWS_ACCOUNT_ID'] = '217833312139'

    _run(test_run, test_file_path, include_advanced=include_advanced)
