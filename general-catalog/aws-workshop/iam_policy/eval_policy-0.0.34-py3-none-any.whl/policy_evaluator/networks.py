from policy_evaluator import constants


class Network:
	def __init__(self, source_ip=None, source_vpc=None, source_vpce=None):
		self.source_ip = source_ip
		self.source_vpc = source_vpc
		self.source_vpce = source_vpce

	def build_context(self):
		context = []
		
		if self.source_ip is not None:
			context.append({
				'ContextKeyName': 'aws:SourceIp',
				'ContextKeyValues': [self.source_ip],
				'ContextKeyType': 'string'
			})
			
		if self.source_vpc is not None:
			context.append({
				'ContextKeyName': 'aws:SourceVpc',
				'ContextKeyValues': [self.source_vpc],
				'ContextKeyType': 'string'
			})
			
		if self.source_vpce is not None:
			context.append({
				'ContextKeyName': 'aws:SourceVpce',
				'ContextKeyValues': [self.source_vpce],
				'ContextKeyType': 'string'
			})

		return context


class MyOnPremisesNetwork(Network):
	def __init__(self, source_ip):
		super().__init__(
			source_ip=source_ip
		)
		self.name = 'My on-premises network'


class NotMyOnPremisesNetwork(Network):
	def __init__(self):
		super().__init__(
			source_ip=constants.not_my_on_premises_ip
		)
		self.name = 'Not my on-premises network'


class MyVpcNetwork(Network):
	def __init__(self, source_vpc, source_vpce):
		super().__init__(
			source_vpc=source_vpc,
			source_vpce=source_vpce
		)
		self.name = 'My VPC network'


class NotMyVpcNetwork(Network):
	def __init__(self):
		super().__init__(
			source_vpc=constants.not_my_vpc_id,
			source_vpce=constants.not_my_vpce_id
		)
		self.name = 'Not my VPC network'
