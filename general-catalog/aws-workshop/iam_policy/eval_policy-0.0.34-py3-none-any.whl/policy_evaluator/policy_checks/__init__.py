from policy_evaluator import constants
from policy_evaluator.constants import bcolors
from policy_evaluator.networks import Network, MyOnPremisesNetwork
from policy_evaluator.principals import Principal, PrincipalWithinMyOrganization
from policy_evaluator.central_logger import log_successful_request, log_failed_request
from policy_evaluator.formatter import build_string, build_request_error


class ExpectedResult:
	ACCESS_DENIED = 'Denied'
	ACCESS_ALLOWED = 'Allowed'


request_id = 1


class Request:
	def __init__(self, action, principal: Principal = None, network: Network = None, resources=None):
		self.action = action
		if principal is None:
			principal = PrincipalWithinMyOrganization()
		self.principal = principal

		if network is None:
			# default to use some SourceIp
			network = MyOnPremisesNetwork(source_ip=constants.my_on_premises_ips[0])
		self.network = network

		if not isinstance(resources, list):
			resources = [resources]
		self.resources = resources

		principal_keys = self.principal.build_context()
		network_keys = self.network.build_context()

		self.context_keys = principal_keys + network_keys

		global request_id
		self.id = request_id
		request_id = request_id + 1

	def build_failed_request_description(
			self,
			request_number,
			resource_that_failed,
			actual_result,
			expected_result,
			hide_resource_output,
			hide_action_output
	):
		principal_in_organization = 'Yes' if self.principal.is_in_my_organization else 'No'
		principal_in_account = 'Yes' if self.principal.is_in_my_account else 'No'

		principal_tag_output = ''
		if self.principal.has_tags:
			principal_tag_output = build_request_error('\tTags on role making request:')
			for tag in self.principal.principal_tags:
				principal_tag_output = principal_tag_output + build_request_error(f'\t\t{tag.key}: {tag.value}')

		resource_tag_output = ''
		if resource_that_failed.has_tags:
			resource_tag_output = build_request_error(f'\tTags on resource:')
			for tag in resource_that_failed.resource_tags:
				resource_tag_output = resource_tag_output + build_request_error(f'\t\t{tag.key}: {tag.value}')

		resource_output = '' if hide_resource_output else build_request_error(f'\tResource: {resource_that_failed.resource_arn}')
		action_output = '' if hide_action_output else build_request_error(f'\tAction: {self.action}')

		return build_request_error(f'Request {request_number}:') + \
			build_request_error(f'\tAccess for this request was: {str(actual_result).lower()}') + \
			build_request_error(f'\tAccess for this request should have been: {str(expected_result).lower()}') + \
			action_output + \
			resource_output + \
			resource_tag_output + \
			build_request_error(f'\tName of role making request: {self.principal.name}') + \
			build_request_error(f'\tRole making request is in the same organization as resource? {principal_in_organization}') + \
			build_request_error(f'\tRole making request is in the same account as resource? {principal_in_account}') + \
			principal_tag_output

	def to_log_entry(self, check_name, resource_that_failed, actual_result):
		return {
			'CheckName': check_name,
			'Result': actual_result,
			'Action': self.action,
			'Resource': resource_that_failed.resource_arn,
			'ResourceTags': [{'Key': tag.key, 'Value': tag.value} for tag in resource_that_failed.resource_tags],
			'OtherResourceContextKeys': [{key['ContextKeyName']: key['ContextKeyValues']} for key in resource_that_failed.other_keys],
			'PrincipalArn': self.principal.principal_arn,
			'PrincipalAccount': self.principal.principal_account,
			'PrincipalIsInMyAccount': self.principal.is_in_my_account,
			'PrincipalOrgId': self.principal.principal_org_id,
			'PrincipalIsInMyOrg': self.principal.is_in_my_organization,
			'PrincipalIsAWSService': self.principal.principal_is_aws_service,
			'PrincipalTags': [{'Key': tag.key, 'Value': tag.value} for tag in self.principal.principal_tags],
			'OtherPrincipalContextKeys': [{key['ContextKeyName']: key['ContextKeyValues']} for key in self.principal.other_keys]
		}


class EvaluationResult:
	def __init__(self, eval_decision, resource):
		normalized_eval_decision = eval_decision.lower()
		if normalized_eval_decision == 'implicitdeny':
			self.friendly_eval_description = 'implicitly denied'
		elif normalized_eval_decision == 'explicitdeny':
			self.friendly_eval_description = 'explicitly denied'
		elif normalized_eval_decision == 'allowed':
			self.friendly_eval_description = 'allowed'
		else:
			raise Exception(f'Unexpected evaluation decision from policy simulator {eval_decision}')

		self.eval_decision = eval_decision
		self.resource = resource


class PolicyCheck:
	def __init__(self, requests: [Request], description: str, expected_result: ExpectedResult):
		self.requests = requests
		self.description = description
		self.expected_result = expected_result
		self.run_for_advanced = True
		self.hide_action_in_output = False
		self.hide_resource_in_output = False

	def run(self, policy_json):
		request_simulations = []
		for request in self.requests:
			request_simulations.append({
				'Request': request,
				'Result': self.evaluate(request, policy_json)
			})

		check_name = self.__class__.__name__

		failed_request_simulations = []
		for request_simulation in request_simulations:
			request_simulation_results = request_simulation['Result']
			request = request_simulation['Request']

			if self.outcome_is_expected(request_simulation_results):
				for result in request_simulation_results:
					log_successful_request(request.id, request.to_log_entry(check_name, result.resource, result.eval_decision))
			else:
				for result in request_simulation_results:
					log_failed_request(request.id, request.to_log_entry(check_name, result.resource, result.eval_decision))

				simulations_that_failed_for_this_request = self.filter_for_failed_evaluations(request_simulation_results)
				failed_request_simulations.append({
					'Request': request_simulation['Request'],
					'Failures': simulations_that_failed_for_this_request
				})

		message = self.description
		if len(failed_request_simulations) == 0:
			actual_result = self.expected_result
			message = build_string(f"{bcolors.OKGREEN}Pass{bcolors.END}", self.expected_result, actual_result, message)
		else:
			actual_result = ExpectedResult.ACCESS_DENIED
			if self.expected_result == ExpectedResult.ACCESS_DENIED:
				actual_result = ExpectedResult.ACCESS_ALLOWED

			message = build_string(f'{bcolors.FAIL}Fail{bcolors.END}', self.expected_result, actual_result, message) + '\n'
			for simulation in failed_request_simulations:
				request = simulation['Request']
				failed_evaluation_results = simulation['Failures']

				request_number = 1
				message = message + build_request_error(f'{bcolors.FAIL}Your policy failed this check because of the request(s) with these details:')
				for evaluation in failed_evaluation_results:
					failed_request_description = request.build_failed_request_description(
						request_number,
						evaluation.resource,
						evaluation.friendly_eval_description,
						self.expected_result,
						self.hide_resource_in_output,
						self.hide_action_in_output
					)
					message = message + failed_request_description + '\n'
					request_number = request_number + 1

				message = message + bcolors.END

		print(message)

	def evaluate(self, request: Request, policy_json) -> [EvaluationResult]:
		# child checks should define this
		raise NotImplementedError()

	def outcome_is_expected(self, evaluation_results: [EvaluationResult]):
		if self.expected_result == ExpectedResult.ACCESS_ALLOWED:
			return all([self.access_is_allowed(result) for result in evaluation_results])
		else:
			return any([self.access_is_explicitly_denied(result) or self.access_is_implicitly_denied(result)
						for result in evaluation_results])

	def filter_for_failed_evaluations(self, evaluation_results: [EvaluationResult]):
		if self.expected_result == ExpectedResult.ACCESS_ALLOWED:
			return [result for result in evaluation_results if not self.access_is_allowed(result)]
		else:
			return [result for result in evaluation_results if
					not self.access_is_explicitly_denied(result) and not self.access_is_implicitly_denied(result)]

	def filter_for_successful_evaluations(self, evaluation_results: [EvaluationResult]):
		if self.expected_result == ExpectedResult.ACCESS_ALLOWED:
			return [result for result in evaluation_results if self.access_is_allowed(result)]
		else:
			return [result for result in evaluation_results if self.access_is_explicitly_denied(result) or
					self.access_is_implicitly_denied(result)]

	@staticmethod
	def access_is_allowed(evaluation_result: EvaluationResult):
		return evaluation_result.eval_decision == 'allowed'

	@staticmethod
	def access_is_explicitly_denied(evaluation_result: EvaluationResult):
		return evaluation_result.eval_decision == 'explicitDeny'

	@staticmethod
	def access_is_implicitly_denied(evaluation_result: EvaluationResult):
		return evaluation_result.eval_decision == 'implicitDeny'

