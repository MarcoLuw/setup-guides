import json

import boto3

from policy_evaluator import constants
from policy_evaluator.policy_checks import PolicyCheck, Request, ExpectedResult, EvaluationResult

iam_client = boto3.client('iam')


class IdentityPolicyCheck(PolicyCheck):
	def __init__(self, requests, description, expected_result: ExpectedResult):
		super().__init__(requests, description, expected_result)

	def evaluate(self, request: Request, identity_policy_json):
		eval_results = []
		for resource in request.resources:
			# we can't use the same context keys for each resource
			context_keys = request.context_keys + resource.build_context()
			response = iam_client.simulate_custom_policy(
				PolicyInputList=[json.dumps(identity_policy_json)],
				ActionNames=[request.action],
				ResourceArns=[resource.resource_arn],
				ResourceOwner=constants.my_account_root,
				CallerArn=request.principal.build_caller_arn(),
				ContextEntries=context_keys
			)
			eval_decision = response['EvaluationResults'][0]['EvalDecision']
			eval_results.append(
				EvaluationResult(eval_decision, resource)
			)

		return eval_results

