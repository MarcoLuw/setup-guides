import copy
import json
import boto3

from policy_evaluator import constants
from policy_evaluator.policy_checks import PolicyCheck, Request, ExpectedResult, EvaluationResult

iam_client = boto3.client('iam')


class ResourcePolicyCheck(PolicyCheck):
	def __init__(self, identity_policy_path, requests, description, expected_result: ExpectedResult):
		super().__init__(requests, description, expected_result)

		with open(identity_policy_path, 'r') as f:
			self.identity_policy = json.load(f)

	def evaluate(self, request: Request, resource_policy_json):
		resource_policy_json = self.__replace_service_principals(resource_policy_json)
		resource_policy_json = self.__replace_role_with_user(resource_policy_json)

		eval_results = []
		for resource in request.resources:
			# we can't use the same context keys for each resource
			context_keys = request.context_keys + resource.build_context()
			response = iam_client.simulate_custom_policy(
				PolicyInputList=[json.dumps(self.identity_policy)],
				ActionNames=[request.action],
				ResourceArns=[resource.resource_arn],
				ResourceOwner=constants.my_account_root,
				ResourcePolicy=json.dumps(resource_policy_json),
				CallerArn=request.principal.build_caller_arn(),
				ContextEntries=context_keys
			)
			eval_decision = response['EvaluationResults'][0]['EvalDecision']
			eval_results.append(
				EvaluationResult(eval_decision, resource)
			)

		return eval_results

	def __replace_service_principals(self, policy):
		# the policy simulator does not support RBPs with service principals, today
		# we run this translation to replace SPs with account numbers and retain the same effective policy
		def replace_service_principals(principal_or_not_principal):
			if not isinstance(principal_or_not_principal, dict):
				return principal_or_not_principal

			service = principal_or_not_principal.get('Service')
			aws = principal_or_not_principal.get('AWS', [])
			if not isinstance(aws, list):
				aws = [aws]

			if service is not None:
				del principal_or_not_principal['Service']
				aws.append(constants.service_principal_account_number)
				principal_or_not_principal['AWS'] = aws

			return principal_or_not_principal

		return self.__translate_principals(policy, replace_service_principals)

	def __replace_role_with_user(self, policy):
		# the policy simulator does not support a callerArn that's a role
		# we run this translation to replace role with user in the principal element and retain the same effective policy
		def replace_role_with_user(principal_or_not_principal):
			if not isinstance(principal_or_not_principal, dict):
				return principal_or_not_principal

			translated_role_principals = []
			aws_principals = principal_or_not_principal.get('AWS', [])
			if not isinstance(aws_principals, list):
				aws_principals = [aws_principals]

			for aws_principal in aws_principals:
				if 'user/' in aws_principal:
					# there's a chance the attendee passes in a user and it works, but this makes sure that won't happen
					translated_principal = f'{aws_principal.split("user/")[0]}role/ThisWillNeverWorkBecauseWeWontUseUsers'
				else:
					translated_principal = aws_principal.replace('role/', 'user/')
				translated_role_principals.append(translated_principal)

			principal_or_not_principal['AWS'] = translated_role_principals
			return principal_or_not_principal

		return self.__translate_principals(policy, replace_role_with_user)

	@staticmethod
	def __translate_principals(policy, translation_function):
		copy_of_policy = copy.deepcopy(policy)

		statements = copy_of_policy.get('Statement', [])
		if not isinstance(statements, list):
			statements = [statements]

		for statement in statements:
			principal = statement.get('Principal')
			if principal is not None:
				principal = translation_function(principal)
				statement['Principal'] = principal
				continue

			not_principal = statement.get('NotPrincipal')
			if not_principal is not None:
				not_principal = translation_function(not_principal)
				statement['NotPrincipal'] = not_principal
				continue

		return copy_of_policy
