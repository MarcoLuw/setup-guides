import json
import boto3
import os

from policy_evaluator.constants import ValidationException, bcolors

client = boto3.client('accessanalyzer')


this_files_directory = os.path.dirname(os.path.realpath(__file__))


def validate(step_number, step, policy_json):
	# first make sure they didn't pass the default policy in, which will never work
	compare_to_default_policy(step_number, policy_json)

	policy_json_as_string = json.dumps(policy_json)
	paginator = client.get_paginator('validate_policy')

	params = {
		'policyDocument': policy_json_as_string,
		'policyType': step.policy_type
	}

	if hasattr(step, 'validate_policy_resource_type'):
		params['validatePolicyResourceType'] = step.validate_policy_resource_type

	response_iterator = paginator.paginate(**params)

	error_findings = []
	for response in response_iterator:
		error_findings.extend([finding for finding in response['findings'] if finding['findingType'] == 'ERROR'])

	if len(error_findings) > 0:
		message = f'{bcolors.FAIL}The policy you submitted is not a valid IAM policy.  Here are the findings:'
		for index, finding in enumerate(error_findings):
			message = message + f'\n\t1: {finding["findingDetails"]}\n'
			try:
				message = message + f'\t\t{__build_path(finding["locations"])}'
			except Exception:
				# if something is wrong with the location parsing logic, fail quietly to give a better UX
				pass

		message = message + bcolors.END

		raise ValidationException(message)


default_policy_mapping = {
	'1': 'step1-user-default.json',
	'2': 'step2-user-default.json',
	'3': 'step3-user-default.json',
	'4': 'step4-user-default.json',
	'5': 'step5-user-default.json',
	'6': 'step6-user-default.json'
}


def compare_to_default_policy(step, policy_json):
	# if the policy matches the default policy, this will not work and indicates that they did not save their policy
	default_policy_filename = default_policy_mapping.get(step)
	if default_policy_filename is None:
		return

	with open(os.path.join(this_files_directory, 'steps', 'policies', default_policy_filename)) as f:
		default_policy = json.load(f)

	if policy_json == default_policy:
		raise ValidationException('The policy you provided is the policy template, which is not a valid IAM policy. Ensure that you save your policy before running an evaluation.')


def __build_path(locations):
	location_paths = []
	for location in locations:
		output_location_path = ''
		path = location.get('path')
		if path is None:
			continue

		for item in path:
			value = item.get('value')
			if value is not None:
				if output_location_path == '':
					output_location_path = value
				else:
					output_location_path = output_location_path + f'.{value}'

			index = item.get('index')
			if index is not None:
				output_location_path = output_location_path + f'[{index}]'

		location_paths.append(output_location_path)

	return f'At path(s): {", ".join(location_paths)}'
