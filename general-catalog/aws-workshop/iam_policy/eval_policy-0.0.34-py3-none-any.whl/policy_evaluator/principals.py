from typing import List
from policy_evaluator import constants


class PrincipalTag:
	def __init__(self, key, value):
		self.key = key
		self.value = value

	def build_context(self):
		return {
			'ContextKeyName': f'aws:PrincipalTag/{self.key}',
			'ContextKeyValues': [self.value],
			'ContextKeyType': 'string'
		}


class Principal:
	def __init__(self, principal_arn, principal_org_id, principal_is_aws_service=False, via_aws_service=False, principal_tags=None):
		self.principal_tags = principal_tags if principal_tags is not None else []
		if not isinstance(self.principal_tags, list):
			self.principal_tags = [self.principal_tags]

		self.principal_is_aws_service = principal_is_aws_service
		self.principal_arn = principal_arn

		principal_account_id = None
		if principal_arn is not None:
			principal_account_id = principal_arn.split(":")[4]
		self.principal_account = principal_account_id
		self.principal_org_id = principal_org_id
		self.principal_type = 'Role'
		self.via_aws_service = via_aws_service
		self.name = 'Default principal name'

		self.is_in_my_organization = self.principal_org_id == constants.my_organization_id
		self.is_in_my_account = self.principal_account == constants.my_account_number

		self.other_keys = []

	@property
	def has_tags(self):
		return len(self.principal_tags) > 0

	def build_caller_arn(self):
		return self.principal_arn.replace('role/', 'user/')

	def add_context_key(self, key, value, key_type='string'):
		if not isinstance(value, list):
			value = [value]

		self.other_keys.append({
			'ContextKeyName': key,
			'ContextKeyValues': value,
			'ContextKeyType': key_type
		})

	def build_context(self):
		context = []

		for tag in self.principal_tags:
			context.append(tag.build_context())

		if self.principal_is_aws_service:
			context.extend([
				{
					'ContextKeyName': 'aws:PrincipalServiceName',
					'ContextKeyValues': ['s3.amazonaws.com'],
					'ContextKeyType': 'string'
				},
				{
					'ContextKeyName': 'aws:PrincipalServiceNamesList',
					'ContextKeyValues': [
						's3.us-east-1.amazonaws.com',
						's3.amazonaws.com'
					],
					'ContextKeyType': 'stringList'
				}
			])

		if self.via_aws_service:
			context.extend([
				{
					'ContextKeyName': 'aws:CalledVia',
					'ContextKeyValues': ['s3.amazonaws.com'],
					'ContextKeyType': 'stringList'
				},
				{
					'ContextKeyName': 'aws:CalledViaFirst',
					'ContextKeyValues': ['s3.amazonaws.com'],
					'ContextKeyType': 'string'
				},
				{
					'ContextKeyName': 'aws:CalledViaLast',
					'ContextKeyValues': ['s3.amazonaws.com'],
					'ContextKeyType': 'string'
				}
			])

		context.extend([
			{
				'ContextKeyName': 'aws:PrincipalIsAWSService',
				'ContextKeyValues': [str(self.principal_is_aws_service)],
				'ContextKeyType': 'boolean'
			},
			{
				'ContextKeyName': 'aws:PrincipalArn',
				'ContextKeyValues': [self.principal_arn],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:PrincipalAccount',
				'ContextKeyValues': [self.principal_account],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:PrincipalOrgId',
				'ContextKeyValues': [self.principal_org_id],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:PrincipalType',
				'ContextKeyValues': [self.principal_type],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:ViaAWSService',
				'ContextKeyValues': [str(self.via_aws_service)],
				'ContextKeyType': 'boolean'
			}
		])

		context.extend(self.other_keys)

		return context


class AnonymousPrincipal(Principal):
	def __init__(self):
		super().__init__(
			principal_arn=None,
			principal_org_id=None
		)
		self.name = 'Anonymous principal'
		self.is_in_my_organization = False
		self.is_in_my_account = False
		self.principal_tags = []

	def build_caller_arn(self):
		# I think this is OK
		return constants.not_my_role_arn.replace("role/", "user/")

	def build_context(self):
		return [
			{
				'ContextKeyName': 'aws:PrincipalAccount',
				'ContextKeyValues': ['anonymous'],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:PrincipalType',
				'ContextKeyValues': ['Anonymous'],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:userid',
				'ContextKeyValues': ['anonymous'],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:ViaAWSService',
				'ContextKeyValues': [str(False)],
				'ContextKeyType': 'boolean'
			}
		]


class PrincipalWithinMyOrganization(Principal):
	def __init__(self, role_name=constants.my_default_role_name, principal_tags: List[PrincipalTag] = None):
		principal_arn = f'arn:aws:iam::{constants.my_other_account_number}:role/{role_name}'
		super().__init__(
			principal_arn=principal_arn,
			principal_org_id=constants.my_organization_id,
			principal_tags=principal_tags
		)
		self.name = role_name


# a special case of principals inside my organization
class PrincipalWithinMyAccount(Principal):
	def __init__(self, role_name=constants.my_default_role_name, principal_tags: List[PrincipalTag] = None):
		principal_arn = f'arn:aws:iam::{constants.my_account_number}:role/{role_name}'
		super().__init__(
			principal_arn=principal_arn,
			principal_org_id=constants.my_organization_id,
			principal_tags=principal_tags
		)
		self.name = role_name


class PrincipalNotInMyAccount(Principal):
	def __init__(self, role_name=constants.not_my_role_name, principal_tags: List[PrincipalTag] = None):
		principal_arn = f'arn:aws:iam::{constants.not_my_account_number}:role/{role_name}'
		super().__init__(
			principal_arn=principal_arn,
			principal_org_id=constants.my_organization_id,
			principal_tags=principal_tags
		)
		self.name = f'{role_name} in {constants.not_my_account_number} account'


class PrincipalOutsideOfMyOrganization(Principal):
	def __init__(self, role_name=constants.not_my_role_name, principal_tags: List[PrincipalTag] = None):
		principal_arn = f'arn:aws:iam::{constants.not_my_account_number}:role/{role_name}'
		super().__init__(
			principal_arn=principal_arn,
			principal_org_id=constants.not_my_organization_id,
			principal_tags=principal_tags
		)
		self.name = 'Role outside of my organization'


class ServicePrincipal(Principal):
	def __init__(self):
		super().__init__(
			principal_arn=constants.service_principal_role_arn,
			principal_org_id=constants.not_my_organization_id,
			principal_is_aws_service=True
		)
		self.name = 'Service principal'

	def add_source_arn(self, source_arn):
		self.add_context_key('aws:SourceArn', source_arn, 'string')

	def add_source_account(self, source_account):
		self.add_context_key('aws:SourceAccount', source_account, 'string')

	def add_source_org_id(self, source_org_id):
		self.add_context_key('aws:SourceOrgId', source_org_id, 'string')
