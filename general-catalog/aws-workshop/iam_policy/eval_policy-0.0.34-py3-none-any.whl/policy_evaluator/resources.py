from policy_evaluator import constants


class ResourceTag:
	def __init__(self, key, value):
		self.key = key
		self.value = value

	def build_context(self):
		return {
			'ContextKeyName': f'aws:ResourceTag/{self.key}',
			'ContextKeyValues': [self.value],
			'ContextKeyType': 'string'
		}


class Resource:
	def __init__(self, resource_account, resource_org_id, resource_arn, resource_name):
		self.resource_account = resource_account
		self.resource_org_id = resource_org_id
		self.resource_arn = resource_arn

		self.name = resource_name
		self.resource_tags = []

		self.other_keys = []

	def add_tag(self, key, value):
		self.resource_tags.append(ResourceTag(key, value))

	def add_context_key(self, key, value, key_type='string'):
		if not isinstance(value, list):
			value = [value]

		self.other_keys.append({
			'ContextKeyName': key,
			'ContextKeyValues': value,
			'ContextKeyType': key_type
		})

	@property
	def has_tags(self):
		return len(self.resource_tags) > 0

	def build_context(self):
		context = []

		for tag in self.resource_tags:
			context.append(tag.build_context())

		context.extend([
			{
				'ContextKeyName': 'aws:ResourceAccount',
				'ContextKeyValues': [self.resource_account],
				'ContextKeyType': 'string'
			},
			{
				'ContextKeyName': 'aws:ResourceOrgId',
				'ContextKeyValues': [self.resource_org_id],
				'ContextKeyType': 'string'
			}
		])

		context.extend(self.other_keys)

		return context


class ResourceWithinMyOrganization(Resource):
	def __init__(self, name, arn):
		super().__init__(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_name=name,
			resource_arn=arn
		)
		self.name = name

