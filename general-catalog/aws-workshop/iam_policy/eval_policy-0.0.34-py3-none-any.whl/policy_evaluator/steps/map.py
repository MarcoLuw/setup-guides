from policy_evaluator.steps.step1 import AllowAccessFromPrincipalsInMyOrganization
from policy_evaluator.steps.step2 import ProtectLandingZoneResources
from policy_evaluator.steps.step3 import RunInstancesWithSpecificInstanceTypeCheck
from policy_evaluator.steps.step4 import ConfusedDeputyCheck
from policy_evaluator.steps.step5 import EnforceLambdaVpcAttachment
from policy_evaluator.steps.step6 import AccessBucketWhoseNameMatchesPrincipalTag
from policy_evaluator.steps.step7 import ControlAccessFromMyS3Bucket

step_evaluator = {
	'1': AllowAccessFromPrincipalsInMyOrganization,
	'2': ProtectLandingZoneResources,
	'3': RunInstancesWithSpecificInstanceTypeCheck,
	'4': ConfusedDeputyCheck,
	'5': EnforceLambdaVpcAttachment,
	'6': AccessBucketWhoseNameMatchesPrincipalTag,
	'7': ControlAccessFromMyS3Bucket
}
