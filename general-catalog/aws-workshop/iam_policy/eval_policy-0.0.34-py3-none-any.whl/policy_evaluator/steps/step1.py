import os

from policy_evaluator.networks import MyVpcNetwork, NotMyVpcNetwork, MyOnPremisesNetwork, NotMyOnPremisesNetwork

from policy_evaluator.policy_checks.resource_policy import ResourcePolicyCheck
from policy_evaluator import constants
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator.resources import Resource
from policy_evaluator.principals import PrincipalWithinMyOrganization, PrincipalWithinMyAccount, AnonymousPrincipal, \
	PrincipalOutsideOfMyOrganization

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class AllowAccessFromPrincipalsInMyOrganization(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='RESOURCE_POLICY', step_number=step_number)
		self.validate_policy_resource_type = 'AWS::S3::Bucket'

		action = 's3:GetObject'
		resource = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn='arn:aws:s3:::MY-BUCKET/my-file.json',
			resource_name='MY-BUCKET/my-file.json'
		)
		resource.add_context_key('s3:ResourceAccount', constants.my_account_number)

		identity_policy_path = os.path.join(this_files_directory, 'policies', 'step1.json')

		self.policy_checks.extend([
			PrincipalsInMyOrganizationAreAllowedAccess(action, resource, identity_policy_path),
			PrincipalsOutsideOfMyOrganizationAreDeniedAccess(action, resource, identity_policy_path),
			AnonymousPrincipalsAreDeniedAccess(action, resource, identity_policy_path)
		])

		advanced_identity_policy_path = os.path.join(this_files_directory, 'policies', 'step1-advanced.json')

		self.advanced_policy_checks.extend([
			PrincipalInMyAccountIsAllowedAccessWithoutAnIdentityPolicy(action, resource, advanced_identity_policy_path)
		])


class PrincipalsInMyOrganizationAreAllowedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path):
		description = 'Principals in my organization should be allowed access'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyOrganization(),
				resources=resource
			),
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_ALLOWED)


class AnonymousPrincipalsAreDeniedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path):
		description = 'Anonymous principals should be denied access'
		requests = [
			Request(
				action=action,
				principal=AnonymousPrincipal(),
				network=MyVpcNetwork(source_vpc=constants.my_vpc_ids[0], source_vpce=constants.my_vpce_id),
				resources=resource
			),
			Request(
				action=action,
				principal=AnonymousPrincipal(),
				network=NotMyVpcNetwork(),
				resources=resource
			),
			Request(
				action=action,
				principal=AnonymousPrincipal(),
				network=MyOnPremisesNetwork(source_ip=constants.my_on_premises_ips[0]),
				resources=resource
			),
			Request(
				action=action,
				principal=AnonymousPrincipal(),
				network=NotMyOnPremisesNetwork(),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalsOutsideOfMyOrganizationAreDeniedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path):
		description = 'Principals outside of my organization should be denied access'
		requests = [
			Request(
				action=action,
				principal=PrincipalOutsideOfMyOrganization(),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalInMyAccountIsAllowedAccessWithoutAnIdentityPolicy(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path):
		description = 'Principals in my account should be denied access without an identity-based policy'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)
