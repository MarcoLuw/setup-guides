import os

from policy_evaluator.policy_checks.service_control_policy import ServiceControlPolicyCheck

from policy_evaluator import constants
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator.resources import Resource
from policy_evaluator.principals import PrincipalWithinMyAccount, PrincipalTag

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class ProtectLandingZoneResources(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='SERVICE_CONTROL_POLICY', step_number=step_number)

		action = 'ec2:ModifyVpcEndpoint'
		platform_resource = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:vpc-endpoint/vpce-adminendpoint',
			resource_name='vpce-adminendpoint'
		)
		platform_resource.add_tag('team', 'admin')

		other_resource = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:vpc-endpoint/vpce-otherendpoint',
			resource_name='vpce-otherendpoint'
		)
		other_resource.add_tag('team', 'other')

		self.policy_checks.extend([
			PrincipalWithAdminTagIsAllowedAccessToResourceWithAdminTag(action, platform_resource),
			PrincipalWithoutAdminTagIsDeniedAccessToResourceWithAdminTag(action, platform_resource),
			PrincipalWithAdminTagIsAllowedAccessToResourceWithOtherTag(action, other_resource),
			PrincipalWithoutAdminTagIsAllowedAccessToResourceWithOtherTag(action, other_resource)
		])

		network_resource = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:vpc-endpoint/vpce-networkowned',
			resource_name='vpce-networkowned'
		)
		network_resource.add_tag('team', 'network-admin')

		self.advanced_policy_checks.extend([
			PrincipalWithAdminTagIsAllowedToAccessResourceWithNetworkTag(action, network_resource),
			PrincipalWithNetworkAdminTagIsAllowedToAccessResourceWithNetworkTag(action, network_resource),
			PrincipalWithNetworkAdminTagIsDeniedAccessResourceWithAdminTag(action, platform_resource),
			PrincipalWithoutAdminOrNetworkAdminTagIsDeniedAccessToResourceWithNetworkAdminTag(action, network_resource),
		])


class PrincipalWithAdminTagIsAllowedAccessToResourceWithAdminTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal with admin tag should be allowed access to resource with admin tag'
		principal_tag = PrincipalTag('team', 'admin')
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name, [principal_tag]),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithoutAdminTagIsDeniedAccessToResourceWithAdminTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal without admin tag should be denied access to resource with admin tag'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithAdminTagIsAllowedAccessToResourceWithOtherTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = f'Principal with admin tag should be allowed access to resource with other tag.'
		principal_tag = PrincipalTag('team', 'admin')
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name, [principal_tag]),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithoutAdminTagIsAllowedAccessToResourceWithOtherTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal without admin tag should be allowed access to resource with other tag'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithAdminTagIsAllowedToAccessResourceWithNetworkTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal with admin tag should be allowed access to resource with network-admin tag'
		principal_tag = PrincipalTag('team', 'admin')
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name, [principal_tag]),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithNetworkAdminTagIsAllowedToAccessResourceWithNetworkTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal with network-admin tag should be allowed access to resource with network-admin tag'
		principal_tag = PrincipalTag('team', 'network-admin')
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name, [principal_tag]),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithNetworkAdminTagIsDeniedAccessResourceWithAdminTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal with network-admin tag should be denied access to resource with admin tag'
		principal_tag = PrincipalTag('team', 'network-admin')
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name, [principal_tag]),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True


class PrincipalWithoutAdminOrNetworkAdminTagIsDeniedAccessToResourceWithNetworkAdminTag(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal without network-admin or admin tag should be denied access to resource with network-admin tag'
		principal_tag = PrincipalTag('team', 'other')
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name, [principal_tag]),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)
		self.hide_action_in_output = True
		self.hide_resource_in_output = True
