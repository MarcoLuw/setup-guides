import os

from policy_evaluator.policy_checks.identity_policy import IdentityPolicyCheck
from policy_evaluator import constants
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator.resources import ResourceTag, ResourceWithinMyOrganization
from policy_evaluator.principals import PrincipalWithinMyAccount

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class RunInstancesWithSpecificInstanceTypeCheck(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='IDENTITY_POLICY', step_number=step_number)

		self.policy_checks.extend([
			PrincipalIsAllowedToLaunchSmallInstances(),
			PrincipalIsNotAllowedToLaunchLargeInstances()
		])

		self.advanced_policy_checks.extend([
			PrincipalIsNotAllowedToLaunchSmallInstancesIntoNonPrivateSubnets(),
			PrincipalIsAllowedToLaunchSmallInstancesIntoPrivateSubnets()
		])


class RunInstancesCheck(IdentityPolicyCheck):
	def __init__(self, description, expected_result, instance_types, subnet_tag: ResourceTag = None, role_name=constants.my_default_role_name):
		description = description

		requests = []
		for instance_type in instance_types:
			resources = self.__build_resources(instance_type, subnet_tag)
			requests.append(
				Request(
					action='ec2:RunInstances',
					principal=PrincipalWithinMyAccount(role_name),
					resources=resources
				)
			)
		super().__init__(requests, description, expected_result)

	@staticmethod
	def __build_resources(instance_type, subnet_tag: ResourceTag = None):
		image = ResourceWithinMyOrganization(
			arn='arn:aws:ec2:us-east-1::image/ami-123456',
			name='ami-123456'
		)

		instance = ResourceWithinMyOrganization(
			arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:instance/i-123456',
			name='i-123456'
		)
		instance.add_context_key('ec2:InstanceType', instance_type)

		network_interface = ResourceWithinMyOrganization(
			arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:network-interface/eni-123456',
			name='eni-123456'
		)

		security_group = ResourceWithinMyOrganization(
			arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:security-group/sg-123456',
			name='sg-123456'
		)

		subnet = ResourceWithinMyOrganization(
			arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:subnet/subnet-123456',
			name='subnet-123456'
		)
		if subnet_tag is not None:
			subnet.add_tag(subnet_tag.key, subnet_tag.value)

		volume = ResourceWithinMyOrganization(
			arn=f'arn:aws:ec2:us-east-1:{constants.my_account_number}:volume/vol-123456',
			name='vol-123456'
		)

		return [image, instance, network_interface, security_group, subnet, volume]


class PrincipalIsAllowedToLaunchSmallInstances(RunInstancesCheck):
	def __init__(self):
		description = 'Principal should be allowed to launch t3.small instance types'
		super().__init__(description, ExpectedResult.ACCESS_ALLOWED, ['t3.small'])
		self.run_for_advanced = False


class PrincipalIsNotAllowedToLaunchLargeInstances(RunInstancesCheck):
	def __init__(self):
		description = 'Principal should be denied access when launching large instance types'
		super().__init__(description, ExpectedResult.ACCESS_DENIED, ['p5.48xlarge'])


class PrincipalIsNotAllowedToLaunchSmallInstancesIntoNonPrivateSubnets(RunInstancesCheck):
	def __init__(self):
		description = 'Principal should be denied access when launching t3.small instance types into non-private subnets'
		super().__init__(
			description,
			ExpectedResult.ACCESS_DENIED,
			['t3.small'],
			ResourceTag('subnet-type', 'public')
		)


class PrincipalIsAllowedToLaunchSmallInstancesIntoPrivateSubnets(RunInstancesCheck):
	def __init__(self):
		description = 'Principal should be allowed to launch t3.small instance types into private subnets'
		super().__init__(
			description,
			ExpectedResult.ACCESS_ALLOWED,
			['t3.small'],
			ResourceTag('subnet-type', 'private')
		)
