import os

from policy_evaluator.policy_checks.resource_policy import ResourcePolicyCheck
from policy_evaluator.principals import ServicePrincipal
from policy_evaluator.networks import NotMyVpcNetwork
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator import constants
from policy_evaluator.resources import Resource

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class ConfusedDeputyCheck(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='RESOURCE_POLICY', step_number=step_number)

		action = 'sns:Publish'
		resource = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn=f'arn:aws:sns:us-east-1:{constants.my_account_number}:MyTopic',
			resource_name='MyTopic'
		)

		identity_policy_path = os.path.join(this_files_directory, 'policies', 'step4.json')
		self.policy_checks.extend([
			S3ServicePrincipalIsAllowedToPublishOnMyBehalf(action, resource, identity_policy_path),
			S3ServicePrincipalIsNotAllowedToPublishFromAnUnknownSourceAccount(action, resource, identity_policy_path)
		])


class S3ServicePrincipalIsAllowedToPublishOnMyBehalf(ResourcePolicyCheck):
	def __init__(self, action, resource, identity_policy_path):
		description = 'S3 service principal should be allowed to publish to my SNS topic on my behalf'

		# this will also work if they just specify the SourceAccount number and I think that's OK
		service_principal = ServicePrincipal()
		service_principal.add_source_arn('arn:aws:s3:::MY-BUCKET')
		service_principal.add_source_account(constants.my_account_number)
		service_principal.add_source_org_id(constants.my_organization_id)

		requests = [
			Request(
				action=action,
				principal=service_principal,
				network=NotMyVpcNetwork(),
				resources=[resource]
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_ALLOWED)


class S3ServicePrincipalIsNotAllowedToPublishFromAnUnknownSourceArn(ResourcePolicyCheck):
	def __init__(self, action, resource, identity_policy_path):
		description = "S3 service principal should be denied access when publishing to my SNS topic on behalf of someone else's bucket"

		service_principal = ServicePrincipal()
		service_principal.add_source_arn('arn:aws:s3:::NOT-MY-BUCKET')
		service_principal.add_source_account(constants.not_my_account_number)
		service_principal.add_source_org_id(constants.not_my_organization_id)

		requests = [
			Request(
				action=action,
				principal=service_principal,
				network=NotMyVpcNetwork(),
				resources=[resource]
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)


class S3ServicePrincipalIsNotAllowedToPublishFromAnUnknownSourceAccount(ResourcePolicyCheck):
	def __init__(self, action, resource, identity_policy_path):
		description = "S3 service principal should be denied access when publishing to my SNS topic on behalf of someone else's account"

		service_principal_not_my_org = ServicePrincipal()
		service_principal_not_my_org.add_source_arn('arn:aws:s3:::MY-BUCKET')
		service_principal_not_my_org.add_source_account(constants.not_my_account_number)
		service_principal_not_my_org.add_source_org_id(constants.not_my_organization_id)

		service_principal_my_org = ServicePrincipal()
		service_principal_my_org.add_source_arn('arn:aws:s3:::MY-BUCKET')
		service_principal_my_org.add_source_account(constants.my_other_account_number)
		service_principal_my_org.add_source_org_id(constants.my_organization_id)

		requests = [
			Request(
				action=action,
				principal=service_principal_not_my_org,
				network=NotMyVpcNetwork(),
				resources=[resource]
			),
			Request(
				action=action,
				principal=service_principal_my_org,
				network=NotMyVpcNetwork(),
				resources=[resource]
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)
