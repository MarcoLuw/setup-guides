import os

from policy_evaluator.policy_checks.service_control_policy import ServiceControlPolicyCheck

from policy_evaluator import constants
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator.resources import Resource
from policy_evaluator.principals import PrincipalWithinMyAccount

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class EnforceLambdaVpcAttachment(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='SERVICE_CONTROL_POLICY', step_number=step_number)

		create_action = 'lambda:CreateFunction'
		update_action = 'lambda:UpdateFunctionConfiguration'
		resource_in_vpc = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn=f'arn:aws:lambda:us-east-1:{constants.my_account_number}:function:my-function',
			resource_name='my-function'
		)
		resource_in_vpc.add_context_key('lambda:VpcIds', 'vpc-01234567890abcdef', 'string')

		resource_not_in_vpc = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn=f'arn:aws:lambda:us-east-1:{constants.my_account_number}:function:my-function',
			resource_name='my-function'
		)

		self.policy_checks.extend([
			PrincipalIsAllowedToCreateVpcAttachedFunction(create_action, resource_in_vpc),
			PrincipalIsAllowedToUpdateVpcAttachedFunctionToRemainVpcAttached(update_action, resource_in_vpc),
			PrincipalIsNotAllowedToCreateNonVpcAttachedFunction(create_action, resource_not_in_vpc),
			PrincipalIsNotAllowedToUpdateVpcAttachedFunctionToRemoveAttachment(update_action, resource_not_in_vpc)
		])


class PrincipalIsAllowedToCreateVpcAttachedFunction(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal is allowed to create a Lambda function in a VPC.'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalIsAllowedToUpdateVpcAttachedFunctionToRemainVpcAttached(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal is allowed to update a lambda function if it remains attached to a VPC.'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalIsNotAllowedToCreateNonVpcAttachedFunction(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal is denied when creating a Lambda function outside of a VPC.'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalIsNotAllowedToUpdateVpcAttachedFunctionToRemoveAttachment(ServiceControlPolicyCheck):
	def __init__(self, action, resource: Resource, role_name=constants.my_default_role_name):
		description = 'Principal is denied when updating a lambda function and removing VPC attachment.'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)
