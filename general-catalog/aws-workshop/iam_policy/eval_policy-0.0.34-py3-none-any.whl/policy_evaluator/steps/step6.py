import os
import string
import random

from policy_evaluator.policy_checks.identity_policy import IdentityPolicyCheck
from policy_evaluator import constants
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator.resources import ResourceWithinMyOrganization
from policy_evaluator.principals import PrincipalWithinMyAccount, PrincipalTag

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class AccessBucketWhoseNameMatchesPrincipalTag(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='IDENTITY_POLICY', step_number=step_number)

		random_tag_value = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
		random_other_value = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
		while random_tag_value == random_other_value:
			random_other_value = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))

		bucket_that_matches = ResourceWithinMyOrganization(
			name=f'mycorp-{random_tag_value}',
			arn=f'arn:aws:s3:::mycorp-{random_tag_value}'
		)

		object_that_matches = ResourceWithinMyOrganization(
			name=f'{bucket_that_matches.name}/object.txt',
			arn=f'{bucket_that_matches.resource_arn}/object.txt'
		)

		bucket_that_doesnt_match = ResourceWithinMyOrganization(
			name=f'mycorp-{random_other_value}',
			arn=f'arn:aws:s3:::mycorp-{random_other_value}'
		)

		object_that_doesnt_match = ResourceWithinMyOrganization(
			name=f'{bucket_that_doesnt_match.name}/object.txt',
			arn=f'{bucket_that_doesnt_match.resource_arn}/object.txt'
		)

		tag = PrincipalTag('department', random_tag_value)
		principal = PrincipalWithinMyAccount(constants.my_default_role_name, principal_tags=[tag])

		self.policy_checks.extend([
			PrincipalIsAllowedToGetObjectsFromBucketWithNameThatMatchesTag(object_that_matches, principal),
			PrincipalIsAllowedToPutObjectsToBucketWithNameThatMatchesTag(object_that_matches, principal),
			PrincipalIsAllowedToListBucketWithNameThatMatchesTag(bucket_that_matches, principal),
			PrincipalIsNotAllowedToGetObjectsFromBucketWithNameThatDoesNotMatchTag(object_that_doesnt_match, principal),
			PrincipalIsNotAllowedToPutObjectsFromBucketWithNameThatDoesNotMatchTag(object_that_doesnt_match, principal),
			PrincipalIsNotAllowedToListBucketWithNameThatDoesNotMatchTag(bucket_that_doesnt_match, principal),
			PrincipalIsNotAllowedToPerformOtherS3Actions(bucket_that_matches, principal)
		])


class PrincipalIsAllowedToGetObjectsFromBucketWithNameThatMatchesTag(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is allowed to get objects from bucket with name that matches tag.'
		requests = [
			Request(
				action='s3:GetObject',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalIsAllowedToPutObjectsToBucketWithNameThatMatchesTag(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is allowed to get objects from bucket with name that matches tag.'
		requests = [
			Request(
				action='s3:PutObject',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalIsAllowedToListBucketWithNameThatMatchesTag(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is allowed to list objects in bucket with name that matches tag.'
		requests = [
			Request(
				action='s3:ListBucket',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalIsNotAllowedToGetObjectsFromBucketWithNameThatDoesNotMatchTag(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is denied from getting objects from bucket with name that does not match tag.'
		requests = [
			Request(
				action='s3:GetObject',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalIsNotAllowedToPutObjectsFromBucketWithNameThatDoesNotMatchTag(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is denied from getting objects from bucket with name that does not match tag.'
		requests = [
			Request(
				action='s3:PutObject',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalIsNotAllowedToListBucketWithNameThatDoesNotMatchTag(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is denied from listing objects in bucket with name that does not match tag.'
		requests = [
			Request(
				action='s3:ListBucket',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalIsNotAllowedToPerformOtherS3Actions(IdentityPolicyCheck):
	def __init__(self, resource, principal):
		description = 'Principal is denied from performing other actions.'
		requests = [
			Request(
				action='s3:PutObjectAcl',
				principal=principal,
				resources=resource
			)
		]
		super().__init__(requests, description, ExpectedResult.ACCESS_DENIED)
