import os

from policy_evaluator.policy_checks.resource_policy import ResourcePolicyCheck
from policy_evaluator import constants
from policy_evaluator.policy_checks import Request, ExpectedResult
from policy_evaluator.resources import Resource
from policy_evaluator.principals import PrincipalWithinMyAccount, \
	PrincipalOutsideOfMyOrganization, PrincipalNotInMyAccount

from policy_evaluator.steps.step_policy_check import StepPolicyCheck

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class ControlAccessFromMyS3Bucket(StepPolicyCheck):
	def __init__(self, step_number):
		super().__init__(policy_type='RESOURCE_POLICY', step_number=step_number)
		self.validate_policy_resource_type = 'AWS::S3::Bucket'

		action = 's3:PutObject'
		resource = Resource(
			resource_account=constants.my_account_number,
			resource_org_id=constants.my_organization_id,
			resource_arn='arn:aws:s3:::MY-BUCKET/my-file.json',
			resource_name='MY-BUCKET/my-file.json'
		)
		resource.add_context_key('s3:ResourceAccount', constants.my_account_number)

		identity_policy_path = os.path.join(this_files_directory, 'policies', 'step7.json')
		self.policy_checks.extend([
			PrincipalDefinedInMyPolicyIsAllowedAccess(action, resource, identity_policy_path, 'Role1'),
			PrincipalDefinedInMyPolicyIsAllowedAccess(action, resource, identity_policy_path, 'Role2'),
			PrincipalNotDefinedInMyPolicyIsDeniedAccess(action, resource, identity_policy_path, 'OtherRole1'),
			PrincipalNotDefinedInMyPolicyIsDeniedAccess(action, resource, identity_policy_path, 'OtherRole2'),
			PrincipalNotInMyAccountIsDeniedAccess(action, resource, identity_policy_path, 'RoleNotInMyAccountAndNotInMyPolicy')
		])

		self.advanced_policy_checks.extend([
			PrincipalDefinedInMyPolicyButNotInMyAccountIsAllowedAccess(action, resource, identity_policy_path),
			PrincipalNotDefinedInMyPolicyButNotInMyAccountIsDeniedAccess(action, resource, identity_policy_path, role_name='OtherRoleInOtherAccount')
		])


class PrincipalDefinedInMyPolicyIsAllowedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path, role_name=constants.my_default_role_name):
		description = f'{role_name} should be allowed access'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalNotInMyAccountIsDeniedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path, role_name=constants.my_default_role_name):
		description = f'Principal from another account should be denied access, even with identity-based policy that allows access'
		requests = [
			Request(
				action=action,
				principal=PrincipalOutsideOfMyOrganization(role_name),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalDefinedInMyPolicyButNotInMyAccountIsAllowedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path, role_name='RoleNotInMyAccount'):
		description = f'{role_name} should be allowed access'
		requests = [
			Request(
				action=action,
				principal=PrincipalNotInMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_ALLOWED)


class PrincipalNotDefinedInMyPolicyIsDeniedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path, role_name=constants.my_default_role_name):
		description = f'Other principal in my account should be denied access, even with identity-based policy that allows access'
		requests = [
			Request(
				action=action,
				principal=PrincipalWithinMyAccount(role_name),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)


class PrincipalNotDefinedInMyPolicyButNotInMyAccountIsDeniedAccess(ResourcePolicyCheck):
	def __init__(self, action, resource: Resource, identity_policy_path, role_name=constants.my_default_role_name):
		description = f'Other principal from another account should be denied access, even with identity-based policy that allows access'
		requests = [
			Request(
				action=action,
				principal=PrincipalOutsideOfMyOrganization(role_name),
				resources=resource
			)
		]
		super().__init__(identity_policy_path, requests, description, ExpectedResult.ACCESS_DENIED)
