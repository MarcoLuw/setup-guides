import os

from policy_evaluator.formatter import build_string
from policy_evaluator.constants import bcolors
from policy_evaluator.central_logger import flush_logs

this_files_directory = os.path.dirname(os.path.realpath(__file__))


class StepPolicyCheck:
	def __init__(self, policy_type, step_number):
		self.policy_checks = []
		self.advanced_policy_checks = []
		self.policy_type = policy_type
		self.step_number = step_number

	def evaluate(self, policy_json, include_advanced):
		print(build_string(' ', f'{bcolors.BOLD}Expected', 'Actual', f'Test details{bcolors.END}'))
		print(build_string(' ', '--------', '------', '-------------'))
		for check in self.policy_checks:
			if not include_advanced or \
					include_advanced and check.run_for_advanced:
				check.run(policy_json)

		if include_advanced:
			for advanced_check in self.advanced_policy_checks:
				advanced_check.run(policy_json)

		step_name = self.__class__.__name__
		flush_logs(step_name, self.step_number, policy_json, include_advanced)
